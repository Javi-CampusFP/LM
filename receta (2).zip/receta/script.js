const form = document.getElementById('recipeForm');
const output = document.getElementById('recipeOutput');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const time = document.getElementById('time').value;
    const ingredients = document.getElementById('ingredients').value.split('\n');
    const steps = document.getElementById('steps').value.split('\n');

    let recipeHTML = `
        <h2>${name}</h2>
        <p><strong>Tiempo de preparación:</strong> ${time} minutos</p>
        <h3>Ingredientes:</h3>
        <ul>
            ${ingredients.map(ing => `<li>${ing}</li>`).join('')}
        </ul>
        <h3>Pasos:</h3>
        <ol>
            ${steps.map(step => `<li>${step}</li>`).join('')}
        </ol>
    `;

    output.innerHTML = recipeHTML;
});
let currentIndex = 0;
const slides = document.querySelectorAll('.carousel-item');
const indicatorsContainer = document.querySelector('.indicators');

// Crear indicadores
slides.forEach((_, index) => {
    const dot = document.createElement('div');
    dot.addEventListener('click', () => goToSlide(index));
    indicatorsContainer.appendChild(dot);
});
const indicators = document.querySelectorAll('.indicators div');

function updateCarousel() {
    slides.forEach((slide, index) => {
        slide.classList.toggle('active', index === currentIndex);
        indicators[index].classList.toggle('active', index === currentIndex);
    });
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % slides.length;
    updateCarousel();
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    updateCarousel();
}

function goToSlide(index) {
    currentIndex = index;
    updateCarousel();
}

// Cambio automático cada 3 segundos
setInterval(nextSlide, 10000);

// Inicializar
updateCarousel();